IPPO Assignment 2 - version 19.1 - 06/11/2019

To create your submission, you should:

* put your worksheet in this directory (doc) with the (exact) name 'worksheet.pdf'

* put all of your source files in the src directory (../src)
  using the conventional hierarchy (i.e. src/main/java, src/main resources, etc.)

* run the command 'gradle zipDist' (in the directory above)
  or run the 'zipDist' target from IntelliJ
  to create your submission zip file

* unpack the resulting zip file (from ../build/distributions)
  and check that it contains all of the files you expect

* submit your zip file
  via the course website
