package ippo.assignment2;
/**Enum Turn class for a simple turn-UUN-s2002073**/
public enum Turn {
    LEFT, RIGHT
}
