package ippo.assignment2;

/**Enum Class for four direction-UUN-s2002073**/

public enum Direction {
        NORTH, SOUTH, EAST, WEST;
}
